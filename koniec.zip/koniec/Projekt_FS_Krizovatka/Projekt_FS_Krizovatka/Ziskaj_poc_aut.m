function [A1,A2,A3] = Ziskaj_poc_aut(pocet_aut_na_kriz)

A1 = pocet_aut_na_kriz(1)+pocet_aut_na_kriz(2);
A2 = pocet_aut_na_kriz(3)+pocet_aut_na_kriz(4);
A3 = pocet_aut_na_kriz(5)+pocet_aut_na_kriz(6);

end